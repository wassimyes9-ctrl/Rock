package com.sketchbot.app

import android.graphics.PointF

/** مرحلة رسم واحدة: لون واحد وخطوطه ونقطة لأخذ لونه من الصورة المرجعية */
class Phase(
    val color: Int,
    val label: String,
    val strokes: List<List<PointF>>,
    val fast: Boolean,
    val pickX: Float = -1f,
    val pickY: Float = -1f,
    // وضع التعبئة: نقاط الضغط بأداة Fill داخل كل منطقة (null = مرحلة رسم عادية)
    val fills: List<PointF>? = null,
    // مرحلة تنعيم: ضربات Smudge قصيرة عبر الحدود بين الألوان
    val blend: Boolean = false
)

object Shared {
    @Volatile var phases: List<Phase> = emptyList()
    @Volatile var imgW: Int = 1
    @Volatile var imgH: Int = 1
    // موضع الجزء المحلَّل داخل الصورة الأصلية الكاملة (نِسَب 0..1)
    @Volatile var fx0: Float = 0f
    @Volatile var fy0: Float = 0f
    @Volatile var fw: Float = 1f
    @Volatile var fh: Float = 1f
    @Volatile var aspect: Float = 1f
    // طبقة جديدة لكل لون
    @Volatile var layers: Boolean = true
    // سرعة الرسم (مضاعف): لا تؤثر على بطء تغيير الألوان
    @Volatile var speed: Float = 4f
}
